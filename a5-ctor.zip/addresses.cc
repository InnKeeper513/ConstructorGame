#include <vector>
#include "Address.h"

std::vector<Address> addresses;
