#ifndef _SUBSCRIPTIONS_H_
#define _SUBSCRIPTIONS_H_
enum class Subscriptions {
Path,
Address,
Tile
};
#endif
