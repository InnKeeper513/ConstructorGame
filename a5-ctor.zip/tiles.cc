#include <vector>
#include "Tile.h"

std::vector<Tile> tiles;
