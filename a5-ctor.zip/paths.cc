#include "Path.h"
#include <vector>

std::vector<Path> paths;
